-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2017 at 09:40 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DCAPTEST`
--

-- --------------------------------------------------------

--
-- Table structure for table `CUSTOMER`
--

CREATE TABLE `CUSTOMER` (
  `c_id` int(11) NOT NULL,
  `c_fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `c_sname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `c_add1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `c_add2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_town` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `c_county` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `c_pcode` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `CUSTOMER`
--

INSERT INTO `CUSTOMER` (`c_id`, `c_fname`, `c_sname`, `c_add1`, `c_add2`, `c_town`, `c_county`, `c_pcode`) VALUES
(7, 'Taylor', 'Swift', '17A Mere Road', NULL, 'Blackpool', 'Lancashire', 'FY3 9AU'),
(8, 'Dave', 'Grohl', '14 Empress Drive', 'North Shore', 'Blackpool', 'Lancashire', 'FY2 9SE'),
(9, 'Katy', 'Perry', '27 Beech Avenue', NULL, 'Blackpool', 'Lancashire', 'FY3 9BB'),
(10, 'Scroobius', 'Pip', 'Flat 30, Singleton Court', 'Chapel Street', '', 'Lancashire', 'FY1 5DA'),
(11, 'Anna', 'Kendrick', '57 Charnley Road', '', 'Blackpool', 'Lancashire', 'FY1 4PE');

-- --------------------------------------------------------

--
-- Table structure for table `PRODUCT`
--

CREATE TABLE `PRODUCT` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `p_price` decimal(10,2) NOT NULL,
  `p_desc` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PRODUCT`
--

INSERT INTO `PRODUCT` (`p_id`, `p_name`, `p_price`, `p_desc`) VALUES
(1, 'Mystery Box', '99.99', 'what\'s in the mystery box?  No-one knows. Except you, if you buy it.  You know you want to buy it.  It\'s so totally mysterious.  Oooooohhhhhhhh...'),
(2, 'Magic Cards', '19.99', 'A deck of magic cards.  Whatever you get people to guess, the right card will appear.  Price does not include magical powers.'),
(3, 'Top Hat', '9.99', 'Look debonair, posh and magic all at once!'),
(4, 'Red Cape', '7.99', 'Swish, swish, swish...'),
(5, 'Blue Cape', '6.99', 'Swoosh, swoosh, swoosh...');

-- --------------------------------------------------------

--
-- Table structure for table `WISHLIST`
--

CREATE TABLE `WISHLIST` (
  `w_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `w_date_added` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `WISHLIST`
--

INSERT INTO `WISHLIST` (`w_id`, `c_id`, `p_id`, `w_date_added`) VALUES
(1, 9, 1, '2017-07-01'),
(3, 10, 2, '2017-12-30'),
(4, 7, 2, '2017-07-12'),
(5, 7, 3, '2017-07-21'),
(6, 8, 5, '2017-07-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CUSTOMER`
--
ALTER TABLE `CUSTOMER`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `PRODUCT`
--
ALTER TABLE `PRODUCT`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `WISHLIST`
--
ALTER TABLE `WISHLIST`
  ADD PRIMARY KEY (`w_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `CUSTOMER`
--
ALTER TABLE `CUSTOMER`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `PRODUCT`
--
ALTER TABLE `PRODUCT`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `WISHLIST`
--
ALTER TABLE `WISHLIST`
  MODIFY `w_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
