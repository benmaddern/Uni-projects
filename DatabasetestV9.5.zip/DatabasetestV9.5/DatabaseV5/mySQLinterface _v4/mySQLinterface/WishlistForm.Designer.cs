﻿namespace mySQLinterface
{
    partial class WishlistForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c_id_lbl = new System.Windows.Forms.Label();
            this.p_id_lbl = new System.Windows.Forms.Label();
            this.w_date_added_lbl = new System.Windows.Forms.Label();
            this.dateformat_lbl = new System.Windows.Forms.Label();
            this.c_id_cmb = new System.Windows.Forms.ComboBox();
            this.p_id_cmb = new System.Windows.Forms.ComboBox();
            this.submit_btn = new System.Windows.Forms.Button();
            this.w_newdate_added_txt = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // c_id_lbl
            // 
            this.c_id_lbl.Location = new System.Drawing.Point(35, 30);
            this.c_id_lbl.Name = "c_id_lbl";
            this.c_id_lbl.Size = new System.Drawing.Size(75, 15);
            this.c_id_lbl.TabIndex = 0;
            this.c_id_lbl.Text = "Customer";
            this.c_id_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // p_id_lbl
            // 
            this.p_id_lbl.Location = new System.Drawing.Point(35, 60);
            this.p_id_lbl.Name = "p_id_lbl";
            this.p_id_lbl.Size = new System.Drawing.Size(75, 15);
            this.p_id_lbl.TabIndex = 1;
            this.p_id_lbl.Text = "Product";
            this.p_id_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // w_date_added_lbl
            // 
            this.w_date_added_lbl.Location = new System.Drawing.Point(35, 90);
            this.w_date_added_lbl.Name = "w_date_added_lbl";
            this.w_date_added_lbl.Size = new System.Drawing.Size(75, 15);
            this.w_date_added_lbl.TabIndex = 2;
            this.w_date_added_lbl.Text = "Date Added";
            this.w_date_added_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dateformat_lbl
            // 
            this.dateformat_lbl.Location = new System.Drawing.Point(140, 120);
            this.dateformat_lbl.Name = "dateformat_lbl";
            this.dateformat_lbl.Size = new System.Drawing.Size(100, 15);
            this.dateformat_lbl.TabIndex = 3;
            this.dateformat_lbl.Text = "Format: yyyy-mm-dd";
            this.dateformat_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // c_id_cmb
            // 
            this.c_id_cmb.FormattingEnabled = true;
            this.c_id_cmb.Location = new System.Drawing.Point(140, 30);
            this.c_id_cmb.Name = "c_id_cmb";
            this.c_id_cmb.Size = new System.Drawing.Size(200, 21);
            this.c_id_cmb.TabIndex = 4;
            // 
            // p_id_cmb
            // 
            this.p_id_cmb.FormattingEnabled = true;
            this.p_id_cmb.Location = new System.Drawing.Point(140, 60);
            this.p_id_cmb.Name = "p_id_cmb";
            this.p_id_cmb.Size = new System.Drawing.Size(200, 21);
            this.p_id_cmb.TabIndex = 5;
            // 
            // submit_btn
            // 
            this.submit_btn.Location = new System.Drawing.Point(140, 150);
            this.submit_btn.Name = "submit_btn";
            this.submit_btn.Size = new System.Drawing.Size(150, 25);
            this.submit_btn.TabIndex = 7;
            this.submit_btn.Text = "Insert / Update";
            this.submit_btn.UseVisualStyleBackColor = true;
            this.submit_btn.Click += new System.EventHandler(this.submit_btn_Click);
            // 
            // w_newdate_added_txt
            // 
            this.w_newdate_added_txt.CustomFormat = "yyyy-MM-dd";
            this.w_newdate_added_txt.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.w_newdate_added_txt.Location = new System.Drawing.Point(140, 90);
            this.w_newdate_added_txt.Name = "w_newdate_added_txt";
            this.w_newdate_added_txt.Size = new System.Drawing.Size(200, 20);
            this.w_newdate_added_txt.TabIndex = 8;
            this.w_newdate_added_txt.ValueChanged += new System.EventHandler(this.w_newdate_added_txt_ValueChanged);
            // 
            // WishlistForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 201);
            this.Controls.Add(this.w_newdate_added_txt);
            this.Controls.Add(this.submit_btn);
            this.Controls.Add(this.p_id_cmb);
            this.Controls.Add(this.c_id_cmb);
            this.Controls.Add(this.dateformat_lbl);
            this.Controls.Add(this.w_date_added_lbl);
            this.Controls.Add(this.p_id_lbl);
            this.Controls.Add(this.c_id_lbl);
            this.Name = "WishlistForm";
            this.Text = "Wishlist Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.WishlistForm_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label c_id_lbl;
        private System.Windows.Forms.Label p_id_lbl;
        private System.Windows.Forms.Label w_date_added_lbl;
        private System.Windows.Forms.Label dateformat_lbl;
        private System.Windows.Forms.ComboBox c_id_cmb;
        private System.Windows.Forms.ComboBox p_id_cmb;
        private System.Windows.Forms.Button submit_btn;
        private System.Windows.Forms.DateTimePicker w_newdate_added_txt;
    }
}