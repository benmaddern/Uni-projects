﻿using MySQL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mySQLinterface
{
    public partial class CustomerForm : Form
    {   //Database connection object
        DBConnection mySqlSrc = new DBConnection();
        // Id field name
        string idFieldName = "c_id";
        
        //List of fields amnd columns apart from id
        List<string> customerFieldList = new List<string>()
        {
            "c_fname", "c_sname", "c_add1", "c_add2", "c_town", "c_county", "c_pcode"};

        //corresponding list of types false is numeric true is string
        List<bool> customerTypeIsStringList = new List<bool>()
        {true, true, true, true, true, true, true};
        //reference to main form (when it closes)
        MainForm mainFormRef;
        //flag for insert: if true in insert mode.. else update
        bool insertFlag = false;
        //row id to update
        string updateId;
      
        //updated contructor to get ref to main form and mode (insert/update)
        //and update record id (set to 0 as default)
        public CustomerForm(ref MainForm mainFormHandle, bool isInsert, string upId = "0")
        {
            //set vars from method parameters
            insertFlag = isInsert;
            mainFormRef = mainFormHandle;
            updateId = upId;
            //intialise form
            InitializeComponent();

            //fileds must be populate after form is initalised
            // if not the controls are null i.e  not yet created
            if (!isInsert)
                PopulateFields();
        }

  
        //in update mode populate fields with exsisting date
        private void PopulateFields()
        {
            //query to get row to update
            List<string>[] UpdateRow = mySqlSrc.SelectRowWithId("CUSTOMER", customerFieldList, idFieldName, updateId);

            //populate text fields from results list
            c_fname_txt.Text = UpdateRow[0][0].ToString();
            c_sname_txt.Text = UpdateRow[1][0].ToString();
            c_add1_txt.Text = UpdateRow[2][0].ToString();
            c_add2_txt.Text = UpdateRow[3][0].ToString();
            c_town_txt.Text = UpdateRow[4][0].ToString();
            c_county_txt.Text = UpdateRow[5][0].ToString();
            c_pcode_txt.Text = UpdateRow[6][0].ToString();
        }

        //method to ensure that all fields have valid values enterd
        public bool ValidateFields()
        {
            //flag for validation
            //(true if valid, set to false if valid data)
            bool validFlag = true;
            //if invalid field message user
            string validMsg = "";

            var regexItem = new Regex(@"[~`!@#$%^&*()+=|\\{}':;.,<>/?[\]""_-]");

            //first name check
            if (c_fname_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a First Name \n\n";
               validFlag = false;
            }

            

            if (regexItem.IsMatch(c_fname_txt.Text.ToString()))
            {
                validMsg += "You have entered an incorrect character in the first name text box \n\n";
                validFlag = false;
            }
      
        
             //surname name check
            if (c_sname_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a Surname \n\n";
                validFlag = false;
            }

            if (regexItem.IsMatch(c_sname_txt.Text.ToString()))
            {
                validMsg += "You have entered an incorrect character in the Surname text box \n\n";
                validFlag = false;
            }

        
            //address 1 check
            if (c_add1_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter Address 1 \n\n";
                validFlag = false;
            }

            if (regexItem.IsMatch(c_add1_txt.Text.ToString()))
            {
                validMsg += "You have entered an incorrect character in the Address text box \n\n";
                validFlag = false;
            }


            //town check
            if (c_town_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a Town \n\n";
                validFlag = false;
            }

            if (regexItem.IsMatch(c_town_txt.Text.ToString()))
            {
                validMsg += "You have entered an incorrect character in the Town text box \n\n";
                validFlag = false;
            }

            //county check
            if (c_county_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a County \n\n";
                validFlag = false;
            }
            if (regexItem.IsMatch(c_county_txt.Text.ToString()))
            {
                validMsg += "You have entered an incorrect character in the county text box \n\n";
                validFlag = false;
            }

            //postcode check
            if (c_pcode_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a Postcode \n\n";
                validFlag = false;
            }

            if (regexItem.IsMatch(c_pcode_txt.Text.ToString()))
            {
                validMsg += "You have entered an incorrect character in the Postcode text box \n\n";
                validFlag = false;
            }

            //if invalid field display message
            if (!validFlag)
                MessageBox.Show(validMsg);
            //return id valid check is ok
            return validFlag;
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
           
            //check if data is valid

            if (ValidateFields())
            {
                
                //create list of values to insert or update from form fields
                List<string> values = new List<string>();

                
                //add in text entered into form fields to values list
                values.Add(c_fname_txt.Text);
                values.Add(c_sname_txt.Text);
                values.Add(c_add1_txt.Text);
                values.Add(c_add2_txt.Text);
                values.Add(c_town_txt.Text);
                values.Add(c_county_txt.Text);
                values.Add(c_pcode_txt.Text);
                

                if (insertFlag)
                {
                    //insert mode branch
                    mySqlSrc.InsertRow("CUSTOMER", customerFieldList, values, customerTypeIsStringList);
                }
                else
                {   //update mode branch
                    mySqlSrc.UpdateRow("CUSTOMER", customerFieldList, values, customerTypeIsStringList, idFieldName, updateId);

                }
                //close subform
                this.Close();


            }
        }
        private void CustomerForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            //set the main form flag to say we are closed now
            mainFormRef.CustomerFormClosed();
        }
    }
}
