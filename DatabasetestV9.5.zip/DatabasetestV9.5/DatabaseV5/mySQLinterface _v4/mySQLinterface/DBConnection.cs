﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySQL_Interface
{
    class DBConnection

    {   //private variables for class
        private MySqlConnection connection;
        private string server;
        private string port;
        private string database;
        private string username;
        private string password;

        public MySqlConnection Connection { get => connection; set => connection = value; }
        
        //method to filter specific wish list results - hardcoded
        public List<string>[] WishlistFilterQuery(string searchField, string searchValue)
        {
            List<string> fieldNames = new List<string>() { "w_id", "c_name", "p_name" };

            //create main list object (rows) to hold indiviual lists (columns)
            List<string>[] results = new List<string>[fieldNames.Count];

            int counter = 0;
            //create individual lists to hold the results for each field or column
            while (counter < fieldNames.Count)
            {
                results[counter] = new List<string>();

                counter++;
            }
            //full query to join WISHLIST, PRODUCT AND CUSTOMER with the fields we require
            string query = "SELECT `WISHLIST`.`w_id`," +
                "CONCAT(`CUSTOMER`.`c_fname`,' ',`CUSTOMER`.`c_sname`) AS 'c_name'," +
                "`PRODUCT`.`p_name`" +

                "FROM `WISHLIST` " +
                "INNER JOIN `CUSTOMER` " +
                "ON `WISHLIST`.`c_id` = `CUSTOMER`.`c_id` " +
                "INNER JOIN `PRODUCT` " +
                "ON `WISHLIST`. `p_id` = `PRODUCT`.`p_id` ";
            //if we are searching on c_id the here is its where clause
            if (searchField == "c_id")
            {
                query += "WHERE `WISHLIST`.`c_id` = " + searchValue;
            }
            //if we are searching on p_id the here is its where clause
            if (searchField == "p_id")
            {
                query += "WHERE `WISHLIST`.`p_id` = " + searchValue;
            }
            //CONNECT, RUN QUERY AND POPULATE FIELD RESULTS
            counter = 0;


            //open connection 
            if (this.OpenConnection())
            {
                //create my sql command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //create a data reader to get the result
                MySqlDataReader dataReader = cmd.ExecuteReader();
                //loop through each row of the results
                while (dataReader.Read())
                {
                    //loop through each field name and add to select statement
                    foreach (var field in fieldNames)
                    {
                        //add value to the results
                        results[counter].Add(dataReader[field].ToString());

                        counter++;
                    }
                    //reset counter before getting the next row
                    counter = 0;
                }
                //close data reader and connection
                dataReader.Close();
                this.CloseConnection();

            }
            //return teh results list
            return results;
        }
        //general purpose select query for searching strings
        public List<string>[] SearchLikeQuery(string tableName, List<string> fieldNames, string searchField, string searchValue)
        {
            //RESULTS LIST CONSTRUCTION -------------------------------------------------
            //create main list objects (rows) to hold individual list (column)
            List<string>[] results = new List<string>[fieldNames.Count];

            //generic counter to be used for loops
            int counter = 0;
            //create the individual lists to hold the results for each field or column
            while (counter < fieldNames.Count)
            {
                
                results[counter] = new List<string>();

                counter++;
            }
            //reset counter
            counter = 0;

            //SELECT QUERY CONTRUCTION ---------------------------------------------
            //query initialisation - SELECT part
            string query = "SELECT ";
            //loop through each field anme and add to select statement
            foreach (var field in fieldNames)
            {  
                //add comma to seperate list items if its not the first item
                if (counter > 0)
                {
                    query += ",";
                }
                //add back quotes around field name and add field to query 
                query += "`" + field + "` ";
                counter++;
            }
            //reset counter
            counter = 0;
            //now add from part - table name with back quotes around it
            query += "FROM " + "`" + tableName + "`";

            //add where clause with like for search
            query += " WHERE " + "`" + searchField + "`" +
                " LIKE " + "'" + "%" + searchValue + "%" + "'";
            //MessageBox.Show(query);

            //open connection
            if (this.OpenConnection())
            {
                //create mySQL command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //create a data reader to get the result
                MySqlDataReader dataReader = cmd.ExecuteReader();
                //loop through each row if results 
                while (dataReader.Read())
                {
                    //loop through each field name and add to select statement
                    foreach (var field in fieldNames)
                    {
                        //in square brackets , string must match
                        //the column and field name on the database
                        // step through to check values

                        //if this is a date value then we need to convert to prevent issues
                        if (dataReader[field].GetType().ToString() ==
                            "MySql.Data.Types.MySqlDateTime")
                        {
                            //get current mysql date object
                            MySql.Data.Types.MySqlDateTime mySqlFormat =
                                (MySql.Data.Types.MySqlDateTime)dataReader[field];
                            //convert to c# date type
                            DateTime csFormat = mySqlFormat.GetDateTime();
                            //format in the mysql style before adding tot eh results
                            results[counter].Add(csFormat.ToString("yyyy-MM-dd"));


                        }
                        else
                        {
                            //add the value to teh results
                            results[counter].Add(dataReader[field].ToString());
                        }
                        counter++;
                    }
                    //reset counter before getting next row of data
                    counter = 0;
                }
                //close data reader and connection
                dataReader.Close();
                this.CloseConnection();

            }
            //return the results list
            return results;
        }
        

        // General purpose insert statement generator and calls for single rows
        // assumes null is allowed for id with auto_increment
        public void InsertRow(string tableName, List<string> fieldNames, List<string> values, List<bool> isStringTypes)
        {
            //build insert query

           
            string query = "INSERT INTO " + "`" + tableName + "`";
            // counter used for loops and comma placemnet
            int counter = 0;
            // add opening brackets for list of fields
            query += " (";
            //loop through fields names and add to insert statement
            foreach (var field in fieldNames)
            {   //if not first item add coma to separte items
                if (counter > 0)
                {
                    query += ",";

                }
                // insert backquotes around field name and add field to query
                query += "`" + field + "` ";

                counter++;

            }
            //use closing brackets for list of fields
            query += ") ";

            //VALUES TO INSERT-----------------------
            
            //reset counter
            counter = 0;

           
            // add values 
            query += "VALUES ";

            //add opeing brackets for list of values
            query += " (";

            //loop through fields names and add to insert statement
            foreach (var value in values)
            {


              
                //if not first item add coma to separte items
                if (counter > 0)
                {
                    query += ",";

                }
                //check to add close quotes if string type

                if (isStringTypes[counter])
                    query += "'";

                query += value;
                //check to add close quotes if string type
                if (isStringTypes[counter])
                    query += "'";
                //update counter
                counter++;

            }
            //add closing brackets for list of values
            query += ") ";

            

            //MessageBox.Show(query);
            //run query
            if (this.OpenConnection())
            {
                //set MySQL command
                MySqlCommand cmd = new MySqlCommand(query, connection);
           
                //execute satement (No results expected)

                cmd.ExecuteNonQuery();
            }
            this.CloseConnection();
        }
        // Contructor
        public DBConnection()
        {
            Initialize();
        }
        // Initailise connection object with connection string
        private void Initialize()
        {
            server = "localhost";
            username = "root";
            password = "";
            port = "3306";
            database = "DCAPTEST";

            //Connect to database using a string
            string connectionString = "SERVER=" + server + ";"
                                   + "PORT=" + port + ";"
                                   + "DATABASE=" + database + ";"
                                   + "UID=" + username + ";"
                                   + "PASSWORD=" + password + ";"
                                   + "ALLOW ZERO DATETIME=True;"
                                   + "CONVERT ZERO DATETIME=True;";

            //store and supply connection string
            connection = new MySqlConnection(connectionString);


        }
        //connect to DB
        private bool OpenConnection()
        {
            try
            {
                //if it connects, return true
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Open fail \n\n" + ex);
                return false;
            }
        }

        private bool CloseConnection()
        {
            //exception handling
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Close fail \n\n" + ex);
                return false;
            }
        }
        //test connection
        public void TestConnection()
        {
            //use the openconnection method
            if (this.OpenConnection())
            {
                //if open show message
                MessageBox.Show("YOU HAVE A CONNECTION!");
            }
            //use the close connection method
            this.CloseConnection();
        }

        //general purpose select statement generator and caller
        public List<string>[] SelectQuery(string tableName, List<string> fieldNames)
        {
            //RESULTS LIST CONTRUCTION -----------------------------------------------------------------

            //create main list object (rows) to hold individual lists (columns)
            List<string>[] results = new List<string>[fieldNames.Count];
            //genreic counter to be used for loops
            int counter = 0;
            //create teh individual lists to hold teh results for each field or column
            while (counter < fieldNames.Count)
            {
                results[counter] = new List<string>();
                counter++;
            }
            //reset counter
            counter = 0;

            //SELECT QUERY CONTRUCTION ------------------------------

            //query initalisation - select part
            string query = "SELECT";

            //loop through each fieldname and add to select statement
            foreach (var field in fieldNames)
            {
                //add comma to seperate list items if not first item
                if (counter > 0)
                {
                    query += ",";
                }
                //add back quotes around field name and add field to query
                query += "`" + field + "` ";
                counter++;
            }
            //reset counter
            counter = 0;
            //add from part - table name with backquotes arount it
            query += "FROM " + "`" + tableName + "`";





            //MessageBox.Show(query);

            if (this.OpenConnection())
            {
                //create my sql command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                // create data reader to get the results
                MySqlDataReader dataReader = cmd.ExecuteReader();
                //loop through each row of results
                while (dataReader.Read())
                {
                    //loop through each field name and add to selected statement
                    foreach (var field in fieldNames)
                    {
                        //if this is a date value then convert to prevent issues
                        if (dataReader[field].GetType().ToString() ==
                            "MySql.Data.Types.MySqlDateTime")
                        {
                            //get the current mysql date object
                            MySql.Data.Types.MySqlDateTime mySqlFormat =
                                (MySql.Data.Types.MySqlDateTime)dataReader[field];
                            //convert to c# date type

                            DateTime csFormat = mySqlFormat.GetDateTime();
                            //format in the MySql style before adding to results

                            results[counter].Add(csFormat.ToString("yyyy-MM-dd"));


                        }
                        else
                        {
                            //add teh value to teh results
                            results[counter].Add(dataReader[field].ToString());
                        }
                        counter++;
                    }
                    //reset counter before next row of data
                    counter = 0;
                }
                //close data reader and connection
                dataReader.Close();
                this.CloseConnection();

            }
            //return results list
            return results;
        }

        //General purpose select statement generator and caller for single row from id
        public List<string>[] SelectRowWithId(string tableName, List<string> fieldNames, string idFieldName, string idValue)
        {
            //RESULTS LIST CONTRUCTION ===============================================
            //create main list object (rows) to hold individual lists (columns)
            List<string>[] results = new List<string>[fieldNames.Count];
            //generic counter to be used for loops
            int counter = 0;
            //create the individual list to hold teh results for each field / column
            while (counter < fieldNames.Count)
            {
                results[counter] = new List<string>();

                counter++;
            }
            //reset counter
            counter = 0;

            //SELECT QUERY CONTRUCTION -------------------------------------------------
            //query initalisation - select part
            string query = "SELECT ";

            //loop through each fieldname and add to select statement
            foreach (var field in fieldNames)
            {
                // add comma to a seperate list item if not first item
                if (counter > 0)
                {
                    query += ",";
                }
                //add backquotes arounf field name and add field to query with a space
                query += "`" + field + "` ";
                counter++;
            }
            //reset counter
            counter = 0;
            // add FROM part - table name with backquotes around it
            query += "FROM " + "`" + tableName + "`";
            // add where part to select the individual row based in ID
            query += " WHERE " + "`" + idFieldName + "`" + "=" + idValue;
            //MessageBox.Show(query);

            //CONNECT, RUN QUERY AND POPULATE RESULTS --------------------------------
            //open connection
            if (this.OpenConnection())
            {
                //create my sql command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                // create data reader to get the results
                MySqlDataReader dataReader = cmd.ExecuteReader();
                //loop through each row of results
                while (dataReader.Read())
                {
                    //loop through each field name and add to selected statement
                    foreach (var field in fieldNames)
                    {
                        //if this is a date value then convert to prevent issues
                        if (dataReader[field].GetType().ToString() ==
                            "MySql.Data.Types.MySqlDateTime")
                        {
                            //get the current mysql date object
                            MySql.Data.Types.MySqlDateTime mySqlFormat =
                                (MySql.Data.Types.MySqlDateTime)dataReader[field];
                            //convert to c# date type

                            DateTime csFormat = mySqlFormat.GetDateTime();
                            //format in the MySql style before adding to results

                            results[counter].Add(csFormat.ToString("yyyy-MM-dd"));


                        }
                        else
                        {
                            //add teh value to teh results
                            results[counter].Add(dataReader[field].ToString());
                        }
                        counter++;
                    }
                    //reset counter before next row of data
                    counter = 0;
                }
                //close data reader and connection
                dataReader.Close();
                this.CloseConnection();

            }
            //return results list
            return results;
        }
        //General purpose delete statement generator and caller
        public void DeleteRowWithId(string tableName, string idFieldName, string idValue)
        {
            //make delete query
            string query = "DELETE FROM " + "`" + tableName + "`" + "WHERE " + "`" + idFieldName + "`" + "=" + idValue;
            //MessageBox.Show(query);
            //run query
            if (this.OpenConnection())
            {
                //set my sql command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                
                //execute statemt
                cmd.ExecuteNonQuery();
            }
            this.CloseConnection();
        }


        //General purpose update statement generator and caller for single row from id
        public void UpdateRow(string tableName, List<string> fieldNames, List<string> values,
            List<bool> isStringTypes, string idFieldName, string idValue)
        {
            //make update query
            string query = "UPDATE " + "`" + tableName + "`";
            //generic counter for loops used for placement of commas
            int counter = 0;
            //set key word
            query += "SET ";
            //loop through each fieldname and add to insert statement
            foreach (var field in fieldNames)
            {
                //add comma to separte list items if not first item
                if (counter > 0)
                {
                    query += ",";
                }
                //add backquotes around field name and add field to query
                query += "`" + field + "`";
                //add the assignmnet operator to link field with value
                query += "=";
                //check to add open quote if string type 
               
                if (isStringTypes[counter])
                    query += "'";

                query += values[counter];
                //check to add close quote if string type
                if (isStringTypes[counter])
                    query += "'";

                counter++;

            }

            //WHERE CLAUSE ---------------------------------------------
            //add where part to select the indiviual row based on ID
            query += "WHERE " + "`" + idFieldName + "`" + "=" + idValue;

            //MessageBox.Show(query);

            //run query
            if (this.OpenConnection())
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.ExecuteNonQuery();
            }
            this.CloseConnection();



        }
  
    }
}