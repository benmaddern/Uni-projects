﻿using MySQL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mySQLinterface
{
    public partial class WishlistForm : Form
    {   //database connection object
        DBConnection mySqlSrc = new DBConnection();
        //id field name
        string idFieldName = "w_id";
        //list of field and column names except iD
        List<string> wishlistFieldList = new List<string>()
        { "c_id", "p_id", "w_date_added"};
        //corrensponding list of types, false is numerical and true is string
        List<bool> wishlistTypeIsStringList = new List<bool>()
        { false, false, true};
        //ref to main form
        MainForm mainFormRef;
        //flag for insert, if true insewrt mode else update
        bool insertFlag = false;
        //row id update
        string updateId;

        //---------------------CUSTOMER TABLE--------------------------------

        //list of field and column names 
        List<string> customerFieldList = new List<string>()
        { "c_id", "c_fname", "c_sname"};

        int customerRows = 0;

        //---------------------PRODUCT TABLE--------------------------------

        List<string> productFieldList = new List<string>()
        { "p_id", "p_name" };

        int productRows;

        //update contructor to get ref to main form and mode (insert or update)
        // also update record id which is set to 0 as default
        public WishlistForm(ref MainForm mainFormHandle, bool isinsert, string upId = "0")
        {
            insertFlag = isinsert;
            mainFormRef = mainFormHandle;
            updateId = upId;

            InitializeComponent();

            //---------------------CUSTOMER COMBO BOX --------------------------------

            //bind combo box to dictionary
            //this allows a key value pair

            Dictionary<string, string> customerItem = new Dictionary<string, string>();
            
            //get new list for results of customer table
            List<string>[] customerResults = new List<string>[customerFieldList.Count];
            customerResults = mySqlSrc.SelectQuery("CUSTOMER", customerFieldList);
            //count rows
            customerRows = customerResults[0].Count;
            for (int i = 0; i < customerRows; i++)
            {   //[column][row]
                //add to the dictionary object id and name
                string fullName = customerResults[1][i] + " " + customerResults[2][i];
                customerItem.Add(customerResults[0][i], fullName);

            }
            //bind the dictionary object and set key -> Value
            //as id => name
            c_id_cmb.DataSource = new BindingSource(customerItem, null);
            c_id_cmb.DisplayMember = "Value";
            c_id_cmb.ValueMember = "Key";

            //--------------------- PRODUCT COMBO BOX --------------------------------

            //bind combo box to dictionary
            //this allows a key value pair
            Dictionary<string, string> productItem = new Dictionary<string, string>();

            //get new list for results of customer table
            List<string>[] productResults = new List<string>[productFieldList.Count];
            productResults = mySqlSrc.SelectQuery("PRODUCT", productFieldList);
            //count rowa
            productRows = productResults[0].Count;
            for (int i = 0; i < productRows; i++)
            {   //[column][row]
                //add to the dictionary object id and name
                productItem.Add(productResults[0][i], productResults[1][i]);
            }
            //bind the dictionary object and set key -> Value
            //as id => name
            p_id_cmb.DataSource = new BindingSource(productItem, null);
            p_id_cmb.DisplayMember = "Value";
            p_id_cmb.ValueMember = "Key";

            if (!insertFlag)
                PopulateFields();
        }
        //in update mode, populate fields with existing data
        private void PopulateFields()
        {   //query to get row to update
            List<string>[] UpdateRow = mySqlSrc.SelectRowWithId("WISHLIST", wishlistFieldList, "w_id", updateId);

            //populate text fields from results list

            //--------------------- CUSTOMER COMBO BOX SELECTION --------------------------------
            //get teh customer id from the selected record
            string tempCustId = UpdateRow[0][0].ToString();
            
            //loop through rows of full customer results
            //loop through combo box and match with cust id
            for (int i = 0; i < customerRows; i++)
            {
                //get customer id of curretn combo box index
                string Key = ((KeyValuePair<string, string>)c_id_cmb.Items[i]).Key;
                //if the value matches the current c_id
                //set the SelectedIndex to this iteration
                //to display correct customer
                if (Key == tempCustId)
                    c_id_cmb.SelectedIndex = i;

            }

            //--------------------- PRODUCT COMBO BOX SELECTION --------------------------------
            // get the product id from teh selected record
            string tempProductId = UpdateRow[1][0].ToString();

            //loop through rows of full customer results
            //loop through combo box and match with cust id
            for (int i = 0; i < productRows; i++)
            {   
                //get the customer id of current combo box index
                string Key = ((KeyValuePair<string, string>)p_id_cmb.Items[i]).Key;
                //if the value matches the current c_id
                //set the SelectedIndex to this iteration
                //to display correct customer
                if (Key == tempProductId)
                    p_id_cmb.SelectedIndex = i;
            }
            w_newdate_added_txt.Text = UpdateRow[2][0].ToString();
        }

        public void SetDateAdded(string value)
        {
            w_newdate_added_txt.Text = value;
        }
        //method to esure that all fields have valid values entered
        public bool ValidateFields()
        {
            //flag for validation
            //(true if valid, set to fasle if invalid data)
            bool validFlag = true;
            //messaeg to display to user if invalid fields
            string validMsg = "";
            //first name check
            if (w_newdate_added_txt.Text.ToString() == "")
            {
                //add to message and set flag to false
                validMsg += "You need to enter the Date Added /n/n";
                validFlag = false;

            }
            else
            {
                //regular expression for yyyy-MM-dd date format
                Regex dateExpression = new Regex("^[0-9]{4}[-]{1}[0-9]{2}[-]{1}[0-9]{2}$");

                //if the date added textbox value doesn't match teh regular expression
                if (!dateExpression.IsMatch(w_newdate_added_txt.Text.ToString()))
                {
                    //add to message and set flag to false
                    validMsg += "Date must be in yyyy-mm-dd format /n/n";
                    validFlag = false;
                }
                else
                {
                    //create Datetime object to try conversation from value entered
                    DateTime outDate;
                    //if can not parse to valid date-- its out of reange
                    ////e.g - no 13th month, then it is invalid
                    if(!(DateTime.TryParse(w_newdate_added_txt.Text.ToString(), out outDate)))
                    {
                        //add to message and set flag to false
                        validMsg += "Invalid date entered /n/n";
                        validFlag = false;
                    }
                }
            }
            //if invalid fields display message to user
            if (!validFlag)
                MessageBox.Show(validMsg);
            //return if valid ckeck if ok or not
            return validFlag;
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            //check teh data is valid
            if (ValidateFields())
            {
                // create a list of values to insert or update from form fields
                List<string> values = new List<string>();
                //add in text entered in form fields to values list
                values.Add(((KeyValuePair<string, string>)c_id_cmb.SelectedItem).Key.ToString());

                values.Add(((KeyValuePair<string, string>)p_id_cmb.SelectedItem).Key.ToString());

                values.Add(w_newdate_added_txt.Text);

                if (insertFlag)
                {
                    //insert mode branch
                    mySqlSrc.InsertRow("WISHLIST", wishlistFieldList, values, wishlistTypeIsStringList);
                }
                else
                {
                    //update mode branch
                    mySqlSrc.UpdateRow("WISHLIST", wishlistFieldList, values, wishlistTypeIsStringList, idFieldName, updateId);

                }
                this.Close();
            }   
        }
        private void WishlistForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            //set the main form flag to say we are closed now
            mainFormRef.WishlistFormClosed();
        }
     

        private void w_newdate_added_txt_ValueChanged(object sender, EventArgs e)
        {
         
        }
            
    }
}
