﻿using MySQL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mySQLinterface
{
    public partial class MainForm : Form
    {
       
        //Databade connection object
        DBConnection mySqlSrc = new DBConnection();
        //----------CUSTOMER TABLE ---------------------
        //list of fields and column names
        List<string> customerFieldList = new List<string>()
        { "c_id", "c_fname", "c_sname", "c_add1", "c_add2", "c_town", "c_county", "c_pcode"};
        //handlers for subforms
        CustomerForm customerFrm;
        public bool customerFrmIsOpen = false;

        //list of fields and column names
        List<string> productFieldList = new List<string>()
        { "p_id", "p_name", "p_price", "p_desc" };

        //handlers for subforms
        ProductForm productFrm;
        public bool productFrmIsOpen = false;
        //-------------------WISHLIST TABLE ---------------------
        //list of fields and column names
        List<string> wishlistFieldList = new List<string>()
        { "w_id", "c_id", "p_id", "w_date_added" };

        //handlers for subforms
        WishlistForm wishlistFrm;
        public bool wishlistFrmIsOpen = false;

        //-----------WISHLIST FILTER--------------------------
        //list of fields and column names
        List<string> wishlistFilterFieldList = new List<string>()
        { "w_id", "c_name", "p_name" };
        //-------------CUSTOMER COMBO BOX --------------------------
        //list of fields and column names
        List<string> customerCmbFieldList = new List<string>()
        { "c_id", "c_fname", "c_sname" };

        int customerRows = 0;
        //-------------PRODUCT COMBO BOX --------------------------
        //list of fields and column names
        List<string> productCmbFieldList = new List<string>()
        { "p_id", "p_name" };

        int productRows = 0;


        public MainForm()
        {
            InitializeComponent();
        }

        //method to refresh data grids based on table given
        //fields selected and data grid indentified and search criteria
        public void SelectResultsAndUpdateGrid(string tableName, List<string> fieldList,
           DataGridView datagridtoUpdate)
        {
            //create results list
            List<string>[] results = new List<string>[fieldList.Count];
            //call select query sending table anme and fields
            results = mySqlSrc.SelectQuery(tableName, fieldList);
            //clear the data grid
            datagridtoUpdate.Rows.Clear();
            //count the rows
            int rows = results[0].Count;
            //loop through each row of the results
            for (int i = 0; i < rows; i++)
            {
                //new string array for new results
                string[] newRow = new string[fieldList.Count];

                for (int j = 0; j < fieldList.Count; j++)
                {
                    //add new item to row
                    //j index is column name and i index is teh current row value
                    newRow[j] = results[j][i];
                }
                //add the complted row to the data grid
                datagridtoUpdate.Rows.Add(newRow);
            }
        }

        public void SelectSearchResultsAndUpdateGrid(string tableName, List<string> fieldList,
            DataGridView datagridtoUpdate, string searchField, string searchValue)
        {
            List<string>[] results = new List<string>[fieldList.Count];

            results = mySqlSrc.SearchLikeQuery(tableName, fieldList, searchField, searchValue);

            datagridtoUpdate.Rows.Clear();

            int rows = results[0].Count;

            for (int i = 0; i < rows; i++)
            {
                string[] newRow = new string[fieldList.Count];

                for (int j = 0; j < fieldList.Count; j++)
                {
                    newRow[j] = results[j][i];
                }

                datagridtoUpdate.Rows.Add(newRow);
            }
        }
    



        //mehtod to mange subforms
        private void CloseAndNullAllSubforms()
        {
            //check each form to see if open flag set
            //if it is tehn close the form and null object/ unset flag
            //CUSTOMER FORM
            if (customerFrmIsOpen)
            {
                customerFrm.Close();
                customerFrm = null;
                customerFrmIsOpen = false;
            }
            //PRODUCT FORM
            if (productFrmIsOpen)
            {   
                productFrm.Close();
                productFrm = null;
                productFrmIsOpen = false;
            }
            //WISHLIST FORM
            if (wishlistFrmIsOpen)
            {
                wishlistFrm.Close();
                wishlistFrm = null;
                wishlistFrmIsOpen = false;
            }
        }
        //Mehtod to check if row is selceted and setlet or update the record based
        //on datagrid indentified and if update flag is set to wither update or delete
        public void DeleteOrUpdateSelectedRow(string tableName, string idFieldname, DataGridView datagridtoUpdate, bool isUpdate)
        {
            //checks to see id row is selcted
            bool isSelected = false;
            int rowId = 0;
            int numRows = 0;

            //nunmber of rows in data grid
            numRows = datagridtoUpdate.Rows.Count;
            //loops through rows
            for (int i = 0; i < numRows; i++)
            {   //if rows selected in data grid
                if (datagridtoUpdate.Rows[i].Selected)
                {
                    //get row id
                    rowId = i;
                    //set selected flag
                    isSelected = true;
                }
            }
            //if row is selceted
            if (isSelected)
            {
                string idValue = datagridtoUpdate.Rows[rowId].Cells[0].Value.ToString();
                //MessageBox.Show(idValue);
                if (isUpdate)
                {


                    CloseAndNullAllSubforms();
                    //create new main form object to send to form as a refernce for Customer form
                    MainForm newform = new MainForm();
                    newform = this;
                    //send form refernece and set insert flag to false
                    //send id from selected row
                    switch (tableName)
                    {

                        case "CUSTOMER":
                            {
                                customerFrm = new CustomerForm(ref newform, false, idValue);
                                //show form and set open flag
                                customerFrm.Show();
                                customerFrmIsOpen = true;
                            }


                            break;

                        case "PRODUCT":
                            {
                                productFrm = new ProductForm(ref newform, false, idValue);
                                //show form and set open flag
                                productFrm.Show();
                                productFrmIsOpen = true;
                            }


                            break;
                        case "WISHLIST":
                            {
                                wishlistFrm = new WishlistForm(ref newform, false, idValue);
                                //show form and set open flag
                                wishlistFrm.Show();
                                wishlistFrmIsOpen = true;
                            }


                            break;
                    }
                }
                else

                    {
                        //calls delete row method on Bb connection and sends the id value to teh selected row
                        mySqlSrc.DeleteRowWithId(tableName, idFieldname, idValue); /// Problem area!!!


                    }


            }
            else
            {
                //if row is not selected then display message to user
                MessageBox.Show("No Row Selected!");
            }
        }
        //populate filter combo boxes for wishlist filter tab
        public void PopulateWishlistFilterCombos()
        {
            //-------------------------CUSTOMER COMBO BOX ----------------------------------
            
            //bind combo box to dictionary
            //this allows us a key value pair
            Dictionary<string, string> customerItem = new Dictionary<string, string>();

            //Get new list for results of customer table
            List<string>[] customerResults = new List<string>[customerCmbFieldList.Count];
            customerResults = mySqlSrc.SelectQuery("CUSTOMER", customerCmbFieldList);
            //counts rows
            customerRows = customerResults[0].Count;
            for (int i = 0; i < customerRows; i++)
            {
                //Column, row
                //add to the dictionary object the id and name
                string fullName = customerResults[1][i] + " " + customerResults[2][i];
                customerItem.Add(customerResults[0][i], fullName);
            }
            //bind the dictionary object and set key -> value
            wf_cust_cmb.DataSource = new BindingSource(customerItem, null);
            wf_cust_cmb.DisplayMember = "Value";
            wf_cust_cmb.ValueMember = "Key";

            //-------------------------PRODUCT COMBO BOX ----------------------------------

            //bind combo box to dictionary
            //this allows us a key value pair
            Dictionary<string, string> productItem = new Dictionary<string, string>();

            //Get new list for results of customer table
            List<string>[] productResults = new List<string>[productCmbFieldList.Count];
            productResults = mySqlSrc.SelectQuery("PRODUCT", productCmbFieldList);
            //counts rows
            productRows = productResults[0].Count;
            for (int i = 0; i < productRows; i++)
            {
                //Column, row
                //add to the dictionary object the id and name
                string productName = productResults[1][i];
                productItem.Add(productResults[0][i], productName);
            }
            //bind the dictionary object and set key -> value
            wf_prod_cmb.DataSource = new BindingSource(productItem, null);
            wf_prod_cmb.DisplayMember = "Value";
            wf_prod_cmb.ValueMember = "Key";

        }
        //customer method for wishlist filters
        public void WishlistFilterSearchAndUpdateGrid(string searchField, string searchValue)
        {
            //create results list
            List<string>[] results = new List<string>[wishlistFilterFieldList.Count];

            //call SELECT  query sending table name and fields
            results = mySqlSrc.WishlistFilterQuery(searchField, searchValue);
            //clear data grid
            wishfilter_dg.Rows.Clear();
            //count the rows
            int rows = results[0].Count;
            //loop through each row of the results
            for (int i = 0; i < rows; i++)
            {
                //new string array for new row
                string[] newRow = new string[wishlistFilterFieldList.Count];

                for (int j = 0; j < wishlistFilterFieldList.Count; j++)
                {
                    //add new item to row
                    //j index is column name and i index for current row value
                    newRow[j] = results[j][i];
                }
                //add teh completed row to teh data grid
                wishfilter_dg.Rows.Add(newRow);
            }
        }


        /// <summary>
        /// //////////////////////////////////////////////////////////////section 3 closeandnullallsubforms
        /// </summary>


        private void test_btn_Click(object sender, EventArgs e)
        {
            //test the database connection
            //a message will apear with result
            mySqlSrc.TestConnection();
        }

        private void select_cust_btn_Click(object sender, EventArgs e)
        {
            SelectResultsAndUpdateGrid("CUSTOMER", customerFieldList, customer_dg);
        }


        private void insert_cust_btn_Click(object sender, EventArgs e)
        {
            CloseAndNullAllSubforms();
            //create new Mainform object to send tot his form
            // as reference for Customer form
            MainForm newform = new MainForm();
            newform = this;
            //send form reference and set insert flag to true
            customerFrm = new CustomerForm(ref newform, true);
            //show form and set open flag
            customerFrm.Show();
            customerFrmIsOpen = true;
        }

        public void CustomerFormClosed()
        {   //reset for and flags
            customerFrmIsOpen = false;
            customerFrm = null;
            //update results
            SelectResultsAndUpdateGrid("CUSTOMER", customerFieldList, customer_dg);
        }

        private void delete_cust_btn_Click(object sender, EventArgs e)
        {
            // send message to user confirming deletion
            // delete then update grid
            if (MessageBox.Show("Are you sure you want to delete this Customer?", "Confirm Delete", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                MessageBox.Show("DELETE");
                DeleteOrUpdateSelectedRow("CUSTOMER", "c_id", customer_dg, false);

                //table name, field list, data grid
                SelectResultsAndUpdateGrid("CUSTOMER", customerFieldList, customer_dg);
            }

            else
            {
                //Code for Cancel action
                MessageBox.Show("ABORT");
            }
        
        }

        private void update_cust_btn_Click(object sender, EventArgs e)
        {
            //table anme, id field name, data grid
            DeleteOrUpdateSelectedRow("CUSTOMER", "c_id", customer_dg, true);

            //SelectResultsAndUpdateGrid("CUSTOMER", customerFieldList, customer_dg);
        }
        private void search_cust_sname_txt_TextChange(object sender, EventArgs e)
        {
            //uncomment to debug and see characters in text box
            //MessageBox.Sow(search_cust_txt.Text.ToString());
            //table name, id field anme, data grid, search field,
            // search value
            SelectSearchResultsAndUpdateGrid("CUSTOMER", customerFieldList, customer_dg, "c_sname", search_cust_sname_txt.Text.ToString());
        }




        private void select_prod_btn_Click(object sender, EventArgs e)
        {
            //table name, field list, data grid
            SelectResultsAndUpdateGrid("PRODUCT", productFieldList, product_dg);
        }

        private void insert_prod_btn_Click(object sender, EventArgs e)
        {
            CloseAndNullAllSubforms();
            //create new Mainform object to send tot his form
            // as reference for Customer form
            MainForm newform = new MainForm();
            newform = this;
            //send form reference and set insert flag to true
            productFrm = new ProductForm(ref newform, true);
            //show form and set open flag
            productFrm.Show();
            productFrmIsOpen = true;
        }

        private void delete_prod_btn_Click(object sender, EventArgs e)
        {
            // send message to user confirming deletion
            // delete then update grid
            if (MessageBox.Show("Are you sure you want to delete this Product?", "Confirm Delete", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                MessageBox.Show("DELETE");
                DeleteOrUpdateSelectedRow("PRODUCT", "p_id", product_dg, false);

                //table name, field list, data grid
                SelectResultsAndUpdateGrid("PRODUCT", productFieldList, product_dg);
            }
              
            else
            {
                //Code for Cancel action
                MessageBox.Show("ABORT");
            }
         
        }
        private void search_prod_name_txt_TextChanged(object sender, EventArgs e)
        {
            SelectSearchResultsAndUpdateGrid("PRODUCT", productFieldList, product_dg, "p_name", search_prod_name_txt.Text.ToString());
        }

        private void update_prod_btn_Click(object sender, EventArgs e)
        {
            //table, id field name, data grid
            DeleteOrUpdateSelectedRow("PRODUCT", "p_id", product_dg, true);
        }
        public void ProductFormClosed()
        {
            //reset form and flags
            productFrmIsOpen = false;
            productFrm = null;
            //update results
            SelectResultsAndUpdateGrid("PRODUCT", productFieldList, product_dg);
        }
        public void WishlistFormClosed()
        {
            //reset form and flags
            wishlistFrmIsOpen = false;
            wishlistFrm = null;
            //udate results
            SelectResultsAndUpdateGrid("WISHLIST", wishlistFieldList, wishlist_dg);
        }

        private void select_wish_btn_Click(object sender, EventArgs e)
        {
            //table name, field list, data drid
            SelectResultsAndUpdateGrid("WISHLIST", wishlistFieldList, wishlist_dg);
        }

        private void insert_wish_btn_Click(object sender, EventArgs e)
        {
            CloseAndNullAllSubforms();

            MainForm newform = new MainForm();
            //create new mainform object to send to this form
            //as reference for customer form
            newform = this;
            //send form refernce and set insert flag to true
            wishlistFrm = new WishlistForm(ref newform, true);
            //show form and set open flag
            wishlistFrm.Show();
            wishlistFrmIsOpen = true;
        }

        private void delete_wish_btn_Click(object sender, EventArgs e)
        {
            // message box asking user to confirm deletion
            if (MessageBox.Show("Are you sure you want to delete this Wishlist?", "Confirm Delete", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                MessageBox.Show("DELETE");
                //delete then update grid

                //table name, id field name, data grid
                DeleteOrUpdateSelectedRow("WISHLIST", "w_id", wishlist_dg, false);

                //table name, field list, data grid
                SelectResultsAndUpdateGrid("WISHLIST", wishlistFieldList, wishlist_dg);
            }

            else
            {
                //Code for Cancel action
                MessageBox.Show("ABORT");
            }
        
        }

        private void update_wish_btn_Click(object sender, EventArgs e)
        {
            //table name, id field name, data grid
            DeleteOrUpdateSelectedRow("WISHLIST", "w_id", wishlist_dg, true);
        }
        //populate filter combo boxes for wishlist filter tab when we enter it
        private void wf_tab_Enter(object sender, EventArgs e)
        {
            PopulateWishlistFilterCombos();
        }
        //when value selected in customer name filter for wishlist filters
        //update the grid
        private void wf_cust_cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            WishlistFilterSearchAndUpdateGrid("c_id",
                (
                (KeyValuePair<string, string>)wf_cust_cmb.SelectedItem)
                .Key.ToString());

        }

        private void search_cust_postcode_txt_TextChanged(object sender, EventArgs e)
        {
            SelectSearchResultsAndUpdateGrid("CUSTOMER", customerFieldList, customer_dg, "c_pcode", search_cust_postcode_txt.Text.ToString());
        }


        //when value selected in product name filter for wishlist filters
        //update the grid
        private void wf_prod_cmb_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            WishlistFilterSearchAndUpdateGrid("p_id",
           (
           (KeyValuePair<string, string>)wf_prod_cmb.SelectedItem)
           .Key.ToString());
        }
    
    }
}
