﻿namespace mySQLinterface
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.test_btn = new System.Windows.Forms.Button();
            this.main_tbc = new System.Windows.Forms.TabControl();
            this.customer_tab = new System.Windows.Forms.TabPage();
            this.search_cust_postcode_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.search_cust_sname_txt = new System.Windows.Forms.TextBox();
            this.search_cust_sname_lbl = new System.Windows.Forms.Label();
            this.update_cust_btn = new System.Windows.Forms.Button();
            this.delete_cust_btn = new System.Windows.Forms.Button();
            this.insert_cust_btn = new System.Windows.Forms.Button();
            this.select_cust_btn = new System.Windows.Forms.Button();
            this.customer_dg = new System.Windows.Forms.DataGridView();
            this.c_id_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_fname_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_sname_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_add1_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_add2_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_town_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_county_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c_pcode_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.product_tab = new System.Windows.Forms.TabPage();
            this.search_prod_name_txt = new System.Windows.Forms.TextBox();
            this.search_prod_name_lbl = new System.Windows.Forms.Label();
            this.update_prod_btn = new System.Windows.Forms.Button();
            this.delete_prod_btn = new System.Windows.Forms.Button();
            this.insert_prod_btn = new System.Windows.Forms.Button();
            this.select_prod_btn = new System.Windows.Forms.Button();
            this.product_dg = new System.Windows.Forms.DataGridView();
            this.p_id_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.p_name_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.p_price_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.p_desc_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wishlist_tab = new System.Windows.Forms.TabPage();
            this.update_wish_btn = new System.Windows.Forms.Button();
            this.delete_wish_btn = new System.Windows.Forms.Button();
            this.insert_wish_btn = new System.Windows.Forms.Button();
            this.select_wish_btn = new System.Windows.Forms.Button();
            this.wishlist_dg = new System.Windows.Forms.DataGridView();
            this.w_id_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wc_id_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wp_id_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.w_date_added_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wf_tab = new System.Windows.Forms.TabPage();
            this.wf_prod_cmb = new System.Windows.Forms.ComboBox();
            this.pf_prod_lbl = new System.Windows.Forms.Label();
            this.wf_cust_cmb = new System.Windows.Forms.ComboBox();
            this.cf_cust_lbl = new System.Windows.Forms.Label();
            this.wishfilter_dg = new System.Windows.Forms.DataGridView();
            this.wf_id_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wf_cname_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wf_pname_clm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.main_tbc.SuspendLayout();
            this.customer_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customer_dg)).BeginInit();
            this.product_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.product_dg)).BeginInit();
            this.wishlist_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wishlist_dg)).BeginInit();
            this.wf_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wishfilter_dg)).BeginInit();
            this.SuspendLayout();
            // 
            // test_btn
            // 
            this.test_btn.Location = new System.Drawing.Point(15, 600);
            this.test_btn.Name = "test_btn";
            this.test_btn.Size = new System.Drawing.Size(125, 25);
            this.test_btn.TabIndex = 0;
            this.test_btn.Text = "Test Connection";
            this.test_btn.UseVisualStyleBackColor = true;
            this.test_btn.Click += new System.EventHandler(this.test_btn_Click);
            // 
            // main_tbc
            // 
            this.main_tbc.Controls.Add(this.customer_tab);
            this.main_tbc.Controls.Add(this.product_tab);
            this.main_tbc.Controls.Add(this.wishlist_tab);
            this.main_tbc.Controls.Add(this.wf_tab);
            this.main_tbc.Location = new System.Drawing.Point(15, 15);
            this.main_tbc.Name = "main_tbc";
            this.main_tbc.SelectedIndex = 0;
            this.main_tbc.Size = new System.Drawing.Size(1110, 580);
            this.main_tbc.TabIndex = 1;
            // 
            // customer_tab
            // 
            this.customer_tab.Controls.Add(this.search_cust_postcode_txt);
            this.customer_tab.Controls.Add(this.label1);
            this.customer_tab.Controls.Add(this.search_cust_sname_txt);
            this.customer_tab.Controls.Add(this.search_cust_sname_lbl);
            this.customer_tab.Controls.Add(this.update_cust_btn);
            this.customer_tab.Controls.Add(this.delete_cust_btn);
            this.customer_tab.Controls.Add(this.insert_cust_btn);
            this.customer_tab.Controls.Add(this.select_cust_btn);
            this.customer_tab.Controls.Add(this.customer_dg);
            this.customer_tab.Location = new System.Drawing.Point(4, 22);
            this.customer_tab.Name = "customer_tab";
            this.customer_tab.Padding = new System.Windows.Forms.Padding(3);
            this.customer_tab.Size = new System.Drawing.Size(1102, 554);
            this.customer_tab.TabIndex = 0;
            this.customer_tab.Text = "Customers";
            this.customer_tab.UseVisualStyleBackColor = true;
            // 
            // search_cust_postcode_txt
            // 
            this.search_cust_postcode_txt.Location = new System.Drawing.Point(775, 29);
            this.search_cust_postcode_txt.Name = "search_cust_postcode_txt";
            this.search_cust_postcode_txt.Size = new System.Drawing.Size(200, 20);
            this.search_cust_postcode_txt.TabIndex = 8;
            this.search_cust_postcode_txt.TextChanged += new System.EventHandler(this.search_cust_postcode_txt_TextChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(660, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Search Postcode";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // search_cust_sname_txt
            // 
            this.search_cust_sname_txt.Location = new System.Drawing.Point(775, 65);
            this.search_cust_sname_txt.Name = "search_cust_sname_txt";
            this.search_cust_sname_txt.Size = new System.Drawing.Size(200, 20);
            this.search_cust_sname_txt.TabIndex = 6;
            this.search_cust_sname_txt.TextChanged += new System.EventHandler(this.search_cust_sname_txt_TextChange);
            // 
            // search_cust_sname_lbl
            // 
            this.search_cust_sname_lbl.Location = new System.Drawing.Point(660, 65);
            this.search_cust_sname_lbl.Name = "search_cust_sname_lbl";
            this.search_cust_sname_lbl.Size = new System.Drawing.Size(110, 15);
            this.search_cust_sname_lbl.TabIndex = 5;
            this.search_cust_sname_lbl.Text = "Search on Surname";
            this.search_cust_sname_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // update_cust_btn
            // 
            this.update_cust_btn.Location = new System.Drawing.Point(500, 60);
            this.update_cust_btn.Name = "update_cust_btn";
            this.update_cust_btn.Size = new System.Drawing.Size(145, 25);
            this.update_cust_btn.TabIndex = 4;
            this.update_cust_btn.Text = "Update Customer";
            this.update_cust_btn.UseVisualStyleBackColor = true;
            this.update_cust_btn.Click += new System.EventHandler(this.update_cust_btn_Click);
            // 
            // delete_cust_btn
            // 
            this.delete_cust_btn.Location = new System.Drawing.Point(340, 60);
            this.delete_cust_btn.Name = "delete_cust_btn";
            this.delete_cust_btn.Size = new System.Drawing.Size(145, 25);
            this.delete_cust_btn.TabIndex = 3;
            this.delete_cust_btn.Text = "Delete Customer";
            this.delete_cust_btn.UseVisualStyleBackColor = true;
            this.delete_cust_btn.Click += new System.EventHandler(this.delete_cust_btn_Click);
            // 
            // insert_cust_btn
            // 
            this.insert_cust_btn.Location = new System.Drawing.Point(180, 60);
            this.insert_cust_btn.Name = "insert_cust_btn";
            this.insert_cust_btn.Size = new System.Drawing.Size(145, 25);
            this.insert_cust_btn.TabIndex = 2;
            this.insert_cust_btn.Text = "Insert Customer";
            this.insert_cust_btn.UseVisualStyleBackColor = true;
            this.insert_cust_btn.Click += new System.EventHandler(this.insert_cust_btn_Click);
            // 
            // select_cust_btn
            // 
            this.select_cust_btn.Location = new System.Drawing.Point(20, 60);
            this.select_cust_btn.Name = "select_cust_btn";
            this.select_cust_btn.Size = new System.Drawing.Size(145, 25);
            this.select_cust_btn.TabIndex = 1;
            this.select_cust_btn.Text = "Select Customers";
            this.select_cust_btn.UseVisualStyleBackColor = true;
            this.select_cust_btn.Click += new System.EventHandler(this.select_cust_btn_Click);
            // 
            // customer_dg
            // 
            this.customer_dg.AllowUserToAddRows = false;
            this.customer_dg.AllowUserToDeleteRows = false;
            this.customer_dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customer_dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.c_id_clm,
            this.c_fname_clm,
            this.c_sname_clm,
            this.c_add1_clm,
            this.c_add2_clm,
            this.c_town_clm,
            this.c_county_clm,
            this.c_pcode_clm});
            this.customer_dg.Location = new System.Drawing.Point(15, 100);
            this.customer_dg.Name = "customer_dg";
            this.customer_dg.ReadOnly = true;
            this.customer_dg.Size = new System.Drawing.Size(1070, 440);
            this.customer_dg.TabIndex = 0;
            // 
            // c_id_clm
            // 
            this.c_id_clm.HeaderText = "Customer ID";
            this.c_id_clm.Name = "c_id_clm";
            this.c_id_clm.ReadOnly = true;
            // 
            // c_fname_clm
            // 
            this.c_fname_clm.HeaderText = "First Name";
            this.c_fname_clm.Name = "c_fname_clm";
            this.c_fname_clm.ReadOnly = true;
            // 
            // c_sname_clm
            // 
            this.c_sname_clm.HeaderText = "Surname";
            this.c_sname_clm.Name = "c_sname_clm";
            this.c_sname_clm.ReadOnly = true;
            // 
            // c_add1_clm
            // 
            this.c_add1_clm.HeaderText = "Address 1";
            this.c_add1_clm.Name = "c_add1_clm";
            this.c_add1_clm.ReadOnly = true;
            // 
            // c_add2_clm
            // 
            this.c_add2_clm.HeaderText = "Address 2";
            this.c_add2_clm.Name = "c_add2_clm";
            this.c_add2_clm.ReadOnly = true;
            // 
            // c_town_clm
            // 
            this.c_town_clm.HeaderText = "Town";
            this.c_town_clm.Name = "c_town_clm";
            this.c_town_clm.ReadOnly = true;
            // 
            // c_county_clm
            // 
            this.c_county_clm.HeaderText = "County";
            this.c_county_clm.Name = "c_county_clm";
            this.c_county_clm.ReadOnly = true;
            // 
            // c_pcode_clm
            // 
            this.c_pcode_clm.HeaderText = "Postcode";
            this.c_pcode_clm.Name = "c_pcode_clm";
            this.c_pcode_clm.ReadOnly = true;
            // 
            // product_tab
            // 
            this.product_tab.Controls.Add(this.search_prod_name_txt);
            this.product_tab.Controls.Add(this.search_prod_name_lbl);
            this.product_tab.Controls.Add(this.update_prod_btn);
            this.product_tab.Controls.Add(this.delete_prod_btn);
            this.product_tab.Controls.Add(this.insert_prod_btn);
            this.product_tab.Controls.Add(this.select_prod_btn);
            this.product_tab.Controls.Add(this.product_dg);
            this.product_tab.Location = new System.Drawing.Point(4, 22);
            this.product_tab.Name = "product_tab";
            this.product_tab.Padding = new System.Windows.Forms.Padding(3);
            this.product_tab.Size = new System.Drawing.Size(1102, 554);
            this.product_tab.TabIndex = 1;
            this.product_tab.Text = "Products";
            this.product_tab.UseVisualStyleBackColor = true;
            // 
            // search_prod_name_txt
            // 
            this.search_prod_name_txt.Location = new System.Drawing.Point(792, 65);
            this.search_prod_name_txt.Name = "search_prod_name_txt";
            this.search_prod_name_txt.Size = new System.Drawing.Size(200, 20);
            this.search_prod_name_txt.TabIndex = 8;
            this.search_prod_name_txt.TextChanged += new System.EventHandler(this.search_prod_name_txt_TextChanged);
            // 
            // search_prod_name_lbl
            // 
            this.search_prod_name_lbl.Location = new System.Drawing.Point(677, 65);
            this.search_prod_name_lbl.Name = "search_prod_name_lbl";
            this.search_prod_name_lbl.Size = new System.Drawing.Size(110, 15);
            this.search_prod_name_lbl.TabIndex = 7;
            this.search_prod_name_lbl.Text = "Search Product Name";
            this.search_prod_name_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // update_prod_btn
            // 
            this.update_prod_btn.Location = new System.Drawing.Point(500, 60);
            this.update_prod_btn.Name = "update_prod_btn";
            this.update_prod_btn.Size = new System.Drawing.Size(145, 25);
            this.update_prod_btn.TabIndex = 4;
            this.update_prod_btn.Text = "Update Product";
            this.update_prod_btn.UseVisualStyleBackColor = true;
            this.update_prod_btn.Click += new System.EventHandler(this.update_prod_btn_Click);
            // 
            // delete_prod_btn
            // 
            this.delete_prod_btn.Location = new System.Drawing.Point(340, 60);
            this.delete_prod_btn.Name = "delete_prod_btn";
            this.delete_prod_btn.Size = new System.Drawing.Size(145, 25);
            this.delete_prod_btn.TabIndex = 3;
            this.delete_prod_btn.Text = "Delete Product";
            this.delete_prod_btn.UseVisualStyleBackColor = true;
            this.delete_prod_btn.Click += new System.EventHandler(this.delete_prod_btn_Click);
            // 
            // insert_prod_btn
            // 
            this.insert_prod_btn.Location = new System.Drawing.Point(180, 60);
            this.insert_prod_btn.Name = "insert_prod_btn";
            this.insert_prod_btn.Size = new System.Drawing.Size(145, 25);
            this.insert_prod_btn.TabIndex = 2;
            this.insert_prod_btn.Text = "Insert Product";
            this.insert_prod_btn.UseVisualStyleBackColor = true;
            this.insert_prod_btn.Click += new System.EventHandler(this.insert_prod_btn_Click);
            // 
            // select_prod_btn
            // 
            this.select_prod_btn.Location = new System.Drawing.Point(20, 60);
            this.select_prod_btn.Name = "select_prod_btn";
            this.select_prod_btn.Size = new System.Drawing.Size(145, 25);
            this.select_prod_btn.TabIndex = 1;
            this.select_prod_btn.Text = "Select Products";
            this.select_prod_btn.UseVisualStyleBackColor = true;
            this.select_prod_btn.Click += new System.EventHandler(this.select_prod_btn_Click);
            // 
            // product_dg
            // 
            this.product_dg.AllowUserToAddRows = false;
            this.product_dg.AllowUserToDeleteRows = false;
            this.product_dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.product_dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.p_id_clm,
            this.p_name_clm,
            this.p_price_clm,
            this.p_desc_clm});
            this.product_dg.Location = new System.Drawing.Point(15, 100);
            this.product_dg.Name = "product_dg";
            this.product_dg.ReadOnly = true;
            this.product_dg.Size = new System.Drawing.Size(1070, 440);
            this.product_dg.TabIndex = 0;
            // 
            // p_id_clm
            // 
            this.p_id_clm.HeaderText = "Product ID";
            this.p_id_clm.Name = "p_id_clm";
            this.p_id_clm.ReadOnly = true;
            // 
            // p_name_clm
            // 
            this.p_name_clm.HeaderText = "Name";
            this.p_name_clm.Name = "p_name_clm";
            this.p_name_clm.ReadOnly = true;
            // 
            // p_price_clm
            // 
            this.p_price_clm.HeaderText = "Price";
            this.p_price_clm.Name = "p_price_clm";
            this.p_price_clm.ReadOnly = true;
            // 
            // p_desc_clm
            // 
            this.p_desc_clm.HeaderText = "Description";
            this.p_desc_clm.Name = "p_desc_clm";
            this.p_desc_clm.ReadOnly = true;
            this.p_desc_clm.Width = 700;
            // 
            // wishlist_tab
            // 
            this.wishlist_tab.Controls.Add(this.update_wish_btn);
            this.wishlist_tab.Controls.Add(this.delete_wish_btn);
            this.wishlist_tab.Controls.Add(this.insert_wish_btn);
            this.wishlist_tab.Controls.Add(this.select_wish_btn);
            this.wishlist_tab.Controls.Add(this.wishlist_dg);
            this.wishlist_tab.Location = new System.Drawing.Point(4, 22);
            this.wishlist_tab.Name = "wishlist_tab";
            this.wishlist_tab.Padding = new System.Windows.Forms.Padding(3);
            this.wishlist_tab.Size = new System.Drawing.Size(1102, 554);
            this.wishlist_tab.TabIndex = 2;
            this.wishlist_tab.Text = "Wishlists";
            this.wishlist_tab.UseVisualStyleBackColor = true;
            // 
            // update_wish_btn
            // 
            this.update_wish_btn.Location = new System.Drawing.Point(500, 60);
            this.update_wish_btn.Name = "update_wish_btn";
            this.update_wish_btn.Size = new System.Drawing.Size(145, 25);
            this.update_wish_btn.TabIndex = 4;
            this.update_wish_btn.Text = "Update Wishlist";
            this.update_wish_btn.UseVisualStyleBackColor = true;
            this.update_wish_btn.Click += new System.EventHandler(this.update_wish_btn_Click);
            // 
            // delete_wish_btn
            // 
            this.delete_wish_btn.Location = new System.Drawing.Point(340, 60);
            this.delete_wish_btn.Name = "delete_wish_btn";
            this.delete_wish_btn.Size = new System.Drawing.Size(145, 25);
            this.delete_wish_btn.TabIndex = 3;
            this.delete_wish_btn.Text = "Delete Wishlist";
            this.delete_wish_btn.UseVisualStyleBackColor = true;
            this.delete_wish_btn.Click += new System.EventHandler(this.delete_wish_btn_Click);
            // 
            // insert_wish_btn
            // 
            this.insert_wish_btn.Location = new System.Drawing.Point(180, 60);
            this.insert_wish_btn.Name = "insert_wish_btn";
            this.insert_wish_btn.Size = new System.Drawing.Size(145, 25);
            this.insert_wish_btn.TabIndex = 2;
            this.insert_wish_btn.Text = "Insert Wishlist";
            this.insert_wish_btn.UseVisualStyleBackColor = true;
            this.insert_wish_btn.Click += new System.EventHandler(this.insert_wish_btn_Click);
            // 
            // select_wish_btn
            // 
            this.select_wish_btn.Location = new System.Drawing.Point(20, 60);
            this.select_wish_btn.Name = "select_wish_btn";
            this.select_wish_btn.Size = new System.Drawing.Size(145, 25);
            this.select_wish_btn.TabIndex = 1;
            this.select_wish_btn.Text = "Select Wishlists";
            this.select_wish_btn.UseVisualStyleBackColor = true;
            this.select_wish_btn.Click += new System.EventHandler(this.select_wish_btn_Click);
            // 
            // wishlist_dg
            // 
            this.wishlist_dg.AllowUserToAddRows = false;
            this.wishlist_dg.AllowUserToDeleteRows = false;
            this.wishlist_dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.wishlist_dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.w_id_clm,
            this.wc_id_clm,
            this.wp_id_clm,
            this.w_date_added_clm});
            this.wishlist_dg.Location = new System.Drawing.Point(15, 100);
            this.wishlist_dg.Name = "wishlist_dg";
            this.wishlist_dg.ReadOnly = true;
            this.wishlist_dg.Size = new System.Drawing.Size(1070, 440);
            this.wishlist_dg.TabIndex = 0;
            // 
            // w_id_clm
            // 
            this.w_id_clm.HeaderText = "Wishlist ID";
            this.w_id_clm.Name = "w_id_clm";
            this.w_id_clm.ReadOnly = true;
            // 
            // wc_id_clm
            // 
            this.wc_id_clm.HeaderText = "Customer ID";
            this.wc_id_clm.Name = "wc_id_clm";
            this.wc_id_clm.ReadOnly = true;
            // 
            // wp_id_clm
            // 
            this.wp_id_clm.HeaderText = "Product ID";
            this.wp_id_clm.Name = "wp_id_clm";
            this.wp_id_clm.ReadOnly = true;
            // 
            // w_date_added_clm
            // 
            this.w_date_added_clm.HeaderText = "Date Added";
            this.w_date_added_clm.Name = "w_date_added_clm";
            this.w_date_added_clm.ReadOnly = true;
            // 
            // wf_tab
            // 
            this.wf_tab.Controls.Add(this.wf_prod_cmb);
            this.wf_tab.Controls.Add(this.pf_prod_lbl);
            this.wf_tab.Controls.Add(this.wf_cust_cmb);
            this.wf_tab.Controls.Add(this.cf_cust_lbl);
            this.wf_tab.Controls.Add(this.wishfilter_dg);
            this.wf_tab.Location = new System.Drawing.Point(4, 22);
            this.wf_tab.Name = "wf_tab";
            this.wf_tab.Padding = new System.Windows.Forms.Padding(3);
            this.wf_tab.Size = new System.Drawing.Size(1102, 554);
            this.wf_tab.TabIndex = 3;
            this.wf_tab.Text = "Wishlist Filters";
            this.wf_tab.UseVisualStyleBackColor = true;
            this.wf_tab.Enter += new System.EventHandler(this.wf_tab_Enter);
            // 
            // wf_prod_cmb
            // 
            this.wf_prod_cmb.FormattingEnabled = true;
            this.wf_prod_cmb.Location = new System.Drawing.Point(517, 57);
            this.wf_prod_cmb.Name = "wf_prod_cmb";
            this.wf_prod_cmb.Size = new System.Drawing.Size(200, 21);
            this.wf_prod_cmb.TabIndex = 4;
            this.wf_prod_cmb.TabStop = false;
            this.wf_prod_cmb.SelectedIndexChanged += new System.EventHandler(this.wf_prod_cmb_SelectedIndexChanged_1);
            // 
            // pf_prod_lbl
            // 
            this.pf_prod_lbl.Location = new System.Drawing.Point(377, 57);
            this.pf_prod_lbl.Name = "pf_prod_lbl";
            this.pf_prod_lbl.Size = new System.Drawing.Size(125, 25);
            this.pf_prod_lbl.TabIndex = 3;
            this.pf_prod_lbl.Text = "Filter By Product";
            // 
            // wf_cust_cmb
            // 
            this.wf_cust_cmb.FormattingEnabled = true;
            this.wf_cust_cmb.Location = new System.Drawing.Point(160, 60);
            this.wf_cust_cmb.Name = "wf_cust_cmb";
            this.wf_cust_cmb.Size = new System.Drawing.Size(200, 21);
            this.wf_cust_cmb.TabIndex = 2;
            this.wf_cust_cmb.TabStop = false;
            this.wf_cust_cmb.SelectedIndexChanged += new System.EventHandler(this.wf_cust_cmb_SelectedIndexChanged);
            // 
            // cf_cust_lbl
            // 
            this.cf_cust_lbl.Location = new System.Drawing.Point(20, 60);
            this.cf_cust_lbl.Name = "cf_cust_lbl";
            this.cf_cust_lbl.Size = new System.Drawing.Size(125, 25);
            this.cf_cust_lbl.TabIndex = 1;
            this.cf_cust_lbl.Text = "Filter By Customer";
            // 
            // wishfilter_dg
            // 
            this.wishfilter_dg.AllowUserToAddRows = false;
            this.wishfilter_dg.AllowUserToDeleteRows = false;
            this.wishfilter_dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.wishfilter_dg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.wf_id_clm,
            this.wf_cname_clm,
            this.wf_pname_clm});
            this.wishfilter_dg.Location = new System.Drawing.Point(15, 100);
            this.wishfilter_dg.Name = "wishfilter_dg";
            this.wishfilter_dg.ReadOnly = true;
            this.wishfilter_dg.Size = new System.Drawing.Size(1070, 440);
            this.wishfilter_dg.TabIndex = 0;
            // 
            // wf_id_clm
            // 
            this.wf_id_clm.HeaderText = "Wishlist ID";
            this.wf_id_clm.Name = "wf_id_clm";
            this.wf_id_clm.ReadOnly = true;
            // 
            // wf_cname_clm
            // 
            this.wf_cname_clm.HeaderText = "Customer Name";
            this.wf_cname_clm.Name = "wf_cname_clm";
            this.wf_cname_clm.ReadOnly = true;
            // 
            // wf_pname_clm
            // 
            this.wf_pname_clm.HeaderText = "Product Name";
            this.wf_pname_clm.Name = "wf_pname_clm";
            this.wf_pname_clm.ReadOnly = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 641);
            this.Controls.Add(this.main_tbc);
            this.Controls.Add(this.test_btn);
            this.Name = "MainForm";
            this.Text = "Natural Selection";
            this.main_tbc.ResumeLayout(false);
            this.customer_tab.ResumeLayout(false);
            this.customer_tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customer_dg)).EndInit();
            this.product_tab.ResumeLayout(false);
            this.product_tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.product_dg)).EndInit();
            this.wishlist_tab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.wishlist_dg)).EndInit();
            this.wf_tab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.wishfilter_dg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button test_btn;
        private System.Windows.Forms.TabControl main_tbc;
        private System.Windows.Forms.TabPage customer_tab;
        private System.Windows.Forms.Button select_cust_btn;
        private System.Windows.Forms.DataGridView customer_dg;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_id_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_fname_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_sname_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_add1_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_add2_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_town_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_county_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn c_pcode_clm;
        private System.Windows.Forms.TabPage product_tab;
        private System.Windows.Forms.Button insert_cust_btn;
        private System.Windows.Forms.Button delete_cust_btn;
        private System.Windows.Forms.Button update_cust_btn;
        private System.Windows.Forms.Button update_prod_btn;
        private System.Windows.Forms.Button delete_prod_btn;
        private System.Windows.Forms.Button insert_prod_btn;
        private System.Windows.Forms.Button select_prod_btn;
        private System.Windows.Forms.DataGridView product_dg;
        private System.Windows.Forms.DataGridViewTextBoxColumn p_id_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn p_name_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn p_price_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn p_desc_clm;
        private System.Windows.Forms.TabPage wishlist_tab;
        private System.Windows.Forms.Button update_wish_btn;
        private System.Windows.Forms.Button delete_wish_btn;
        private System.Windows.Forms.Button insert_wish_btn;
        private System.Windows.Forms.Button select_wish_btn;
        private System.Windows.Forms.DataGridView wishlist_dg;
        private System.Windows.Forms.DataGridViewTextBoxColumn w_id_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn wc_id_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn wp_id_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn w_date_added_clm;
        private System.Windows.Forms.TextBox search_cust_sname_txt;
        private System.Windows.Forms.Label search_cust_sname_lbl;
        private System.Windows.Forms.TabPage wf_tab;
        private System.Windows.Forms.ComboBox wf_cust_cmb;
        private System.Windows.Forms.Label cf_cust_lbl;
        private System.Windows.Forms.DataGridView wishfilter_dg;
        private System.Windows.Forms.DataGridViewTextBoxColumn wf_id_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn wf_cname_clm;
        private System.Windows.Forms.DataGridViewTextBoxColumn wf_pname_clm;
        private System.Windows.Forms.TextBox search_cust_postcode_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox search_prod_name_txt;
        private System.Windows.Forms.Label search_prod_name_lbl;
        private System.Windows.Forms.ComboBox wf_prod_cmb;
        private System.Windows.Forms.Label pf_prod_lbl;
    }
}

