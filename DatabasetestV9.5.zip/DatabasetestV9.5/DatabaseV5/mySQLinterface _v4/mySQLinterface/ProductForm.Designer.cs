﻿namespace mySQLinterface
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p_name_lbl = new System.Windows.Forms.Label();
            this.p_desc_lbl = new System.Windows.Forms.Label();
            this.p_price_lbl = new System.Windows.Forms.Label();
            this.p_name_txt = new System.Windows.Forms.TextBox();
            this.p_desc_txt = new System.Windows.Forms.TextBox();
            this.p_price_txt = new System.Windows.Forms.TextBox();
            this.submit_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // p_name_lbl
            // 
            this.p_name_lbl.Location = new System.Drawing.Point(35, 30);
            this.p_name_lbl.Name = "p_name_lbl";
            this.p_name_lbl.Size = new System.Drawing.Size(75, 15);
            this.p_name_lbl.TabIndex = 0;
            this.p_name_lbl.Text = "Product Name";
            // 
            // p_desc_lbl
            // 
            this.p_desc_lbl.Location = new System.Drawing.Point(35, 90);
            this.p_desc_lbl.Name = "p_desc_lbl";
            this.p_desc_lbl.Size = new System.Drawing.Size(75, 15);
            this.p_desc_lbl.TabIndex = 1;
            this.p_desc_lbl.Text = "Description";
            // 
            // p_price_lbl
            // 
            this.p_price_lbl.Location = new System.Drawing.Point(35, 60);
            this.p_price_lbl.Name = "p_price_lbl";
            this.p_price_lbl.Size = new System.Drawing.Size(75, 15);
            this.p_price_lbl.TabIndex = 2;
            this.p_price_lbl.Text = "Sale Price";
            // 
            // p_name_txt
            // 
            this.p_name_txt.Location = new System.Drawing.Point(140, 30);
            this.p_name_txt.Name = "p_name_txt";
            this.p_name_txt.Size = new System.Drawing.Size(200, 20);
            this.p_name_txt.TabIndex = 5;
            // 
            // p_desc_txt
            // 
            this.p_desc_txt.Location = new System.Drawing.Point(140, 90);
            this.p_desc_txt.Multiline = true;
            this.p_desc_txt.Name = "p_desc_txt";
            this.p_desc_txt.Size = new System.Drawing.Size(200, 180);
            this.p_desc_txt.TabIndex = 6;
            // 
            // p_price_txt
            // 
            this.p_price_txt.Location = new System.Drawing.Point(140, 60);
            this.p_price_txt.Name = "p_price_txt";
            this.p_price_txt.Size = new System.Drawing.Size(200, 20);
            this.p_price_txt.TabIndex = 7;
            // 
            // submit_btn
            // 
            this.submit_btn.Location = new System.Drawing.Point(140, 285);
            this.submit_btn.Name = "submit_btn";
            this.submit_btn.Size = new System.Drawing.Size(150, 25);
            this.submit_btn.TabIndex = 8;
            this.submit_btn.Text = "Insert / Update";
            this.submit_btn.UseVisualStyleBackColor = true;
            this.submit_btn.Click += new System.EventHandler(this.submit_btn_Click);
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 321);
            this.Controls.Add(this.submit_btn);
            this.Controls.Add(this.p_price_txt);
            this.Controls.Add(this.p_desc_txt);
            this.Controls.Add(this.p_name_txt);
            this.Controls.Add(this.p_price_lbl);
            this.Controls.Add(this.p_desc_lbl);
            this.Controls.Add(this.p_name_lbl);
            this.Name = "ProductForm";
            this.Text = "Product Form";
            this.ResumeLayout(false);
            this.PerformLayout();

            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ProductForm_FormClosed);

        }

        #endregion

        private System.Windows.Forms.Label p_name_lbl;
        private System.Windows.Forms.Label p_desc_lbl;
        private System.Windows.Forms.Label p_price_lbl;
        private System.Windows.Forms.TextBox p_name_txt;
        private System.Windows.Forms.TextBox p_desc_txt;
        private System.Windows.Forms.TextBox p_price_txt;
        private System.Windows.Forms.Button submit_btn;
    }
}