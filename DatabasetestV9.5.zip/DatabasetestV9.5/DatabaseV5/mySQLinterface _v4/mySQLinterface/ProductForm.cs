﻿using MySQL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mySQLinterface
{
    public partial class ProductForm : Form
    {
        //Database connection object
        DBConnection mySqlSrc = new DBConnection();
        //id field name
        string idFieldName = "p_id";
        //list of fields/column names apart from ID
        List<string> productFieldList = new List<string>()
        { "p_name", "p_price", "p_desc" };
        //corressponding list of types; false is numeric and true is a string
        List<bool> productTypeIsStringList = new List<bool>()
        { true, false, true };
        //reference main form
        MainForm mainFormRef;
        //flag for insert, if true in insert mode otherwise update
        bool insertFlag = false;
        //row id to update
        string updateId;

        //updated contructor to get ref to main form and mode either insert or update
        //+ update record id - default set to 0
        public ProductForm(ref MainForm mainFormHandle, bool isInsert, string upId = "0")
        {
            insertFlag = isInsert;
            mainFormRef = mainFormHandle;
            updateId = upId;

            InitializeComponent();
            //fields must be populated afte form initialised
            // else the controls are null and not yet created
            if (!isInsert)
                PopulateFields();
        }
        // in update mode, populate field with existing data
        private void PopulateFields()
        {
            //query to get row to update
            List<string>[] UpdateRow = mySqlSrc.SelectRowWithId("PRODUCT", productFieldList, "p_id", updateId);
            //populate text fields from results list
            p_name_txt.Text = UpdateRow[0][0].ToString();
            p_price_txt.Text = UpdateRow[1][0].ToString();
            p_desc_txt.Text = UpdateRow[2][0].ToString();
        }
        public bool ValidateFields()
        {
            //flag for validation
            //true for valid and falsi if invalid
            bool validFlag = true;
            //message to display to user if invalid fields
            string validMsg = "";

            //product name check
            if (p_name_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a Product Name \n\n";
                validFlag = false;

            }
            //product price check
            if (p_price_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a Price \n\n";
                validFlag = false;
            }
            //additional checks for decimal value
            else
            {
                decimal number;
                if (
                    !(Decimal.TryParse(p_price_txt.Text.ToString(), out number)))
                {
                    //add message and set flag to false
                    validMsg += "Price needs to be valid decimal \n\n";
                    validFlag = false;
                    
                }
            }
            //Product description check
            if (p_desc_txt.Text.ToString() == "")
            {
                //add message and set flag to false
                validMsg += "You need to enter a Description \n\n";
                validFlag = false;
            }
            //if invalid fields show message
            if (!validFlag)
                MessageBox.Show(validMsg);
            //return valid check regardless of result
            return validFlag;
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            //check data is valid
            if (ValidateFields())
            {
                //create list of values to insert or update from form fields
                List<string> values = new List<string>();
                //add in text entered into form fields to values list
                values.Add(p_name_txt.Text);
                values.Add(p_price_txt.Text);
                values.Add(p_desc_txt.Text);
            

                if (insertFlag)
                {
                    //insert mode
                    mySqlSrc.InsertRow("PRODUCT", productFieldList, values, productTypeIsStringList);
                }
                else
                {
                    //update mode
                    mySqlSrc.UpdateRow("PRODUCT", productFieldList, values, productTypeIsStringList, idFieldName, updateId);

                }
                this.Close();
            }
        }
        private void ProductForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            //set the main form flag to say we are closed 
            mainFormRef.ProductFormClosed();
        }
    
    }
}
