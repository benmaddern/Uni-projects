﻿namespace mySQLinterface
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c_fname_lbl = new System.Windows.Forms.Label();
            this.c_pcode_lbl = new System.Windows.Forms.Label();
            this.c_county_lbl = new System.Windows.Forms.Label();
            this.c_town_lbl = new System.Windows.Forms.Label();
            this.c_add2_lbl = new System.Windows.Forms.Label();
            this.c_add1_lbl = new System.Windows.Forms.Label();
            this.c_sname_lbl = new System.Windows.Forms.Label();
            this.c_fname_txt = new System.Windows.Forms.TextBox();
            this.c_pcode_txt = new System.Windows.Forms.TextBox();
            this.c_county_txt = new System.Windows.Forms.TextBox();
            this.c_town_txt = new System.Windows.Forms.TextBox();
            this.c_add2_txt = new System.Windows.Forms.TextBox();
            this.c_add1_txt = new System.Windows.Forms.TextBox();
            this.c_sname_txt = new System.Windows.Forms.TextBox();
            this.submit_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // c_fname_lbl
            // 
            this.c_fname_lbl.Location = new System.Drawing.Point(35, 30);
            this.c_fname_lbl.Name = "c_fname_lbl";
            this.c_fname_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_fname_lbl.TabIndex = 0;
            this.c_fname_lbl.Text = "First Name";
            // 
            // c_pcode_lbl
            // 
            this.c_pcode_lbl.Location = new System.Drawing.Point(35, 210);
            this.c_pcode_lbl.Name = "c_pcode_lbl";
            this.c_pcode_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_pcode_lbl.TabIndex = 1;
            this.c_pcode_lbl.Text = "Postcode";
            // 
            // c_county_lbl
            // 
            this.c_county_lbl.Location = new System.Drawing.Point(35, 180);
            this.c_county_lbl.Name = "c_county_lbl";
            this.c_county_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_county_lbl.TabIndex = 2;
            this.c_county_lbl.Text = "County";
            // 
            // c_town_lbl
            // 
            this.c_town_lbl.Location = new System.Drawing.Point(35, 150);
            this.c_town_lbl.Name = "c_town_lbl";
            this.c_town_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_town_lbl.TabIndex = 3;
            this.c_town_lbl.Text = "Town";
            // 
            // c_add2_lbl
            // 
            this.c_add2_lbl.Location = new System.Drawing.Point(35, 120);
            this.c_add2_lbl.Name = "c_add2_lbl";
            this.c_add2_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_add2_lbl.TabIndex = 4;
            this.c_add2_lbl.Text = "Address 2";
            // 
            // c_add1_lbl
            // 
            this.c_add1_lbl.Location = new System.Drawing.Point(35, 90);
            this.c_add1_lbl.Name = "c_add1_lbl";
            this.c_add1_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_add1_lbl.TabIndex = 5;
            this.c_add1_lbl.Text = "Address 1";
            // 
            // c_sname_lbl
            // 
            this.c_sname_lbl.Location = new System.Drawing.Point(35, 60);
            this.c_sname_lbl.Name = "c_sname_lbl";
            this.c_sname_lbl.Size = new System.Drawing.Size(60, 15);
            this.c_sname_lbl.TabIndex = 6;
            this.c_sname_lbl.Text = "Surname";
            this.c_sname_lbl.UseMnemonic = false;
            // 
            // c_fname_txt
            // 
            this.c_fname_txt.Location = new System.Drawing.Point(125, 30);
            this.c_fname_txt.Name = "c_fname_txt";
            this.c_fname_txt.Size = new System.Drawing.Size(200, 20);
            this.c_fname_txt.TabIndex = 7;
            // 
            // c_pcode_txt
            // 
            this.c_pcode_txt.Location = new System.Drawing.Point(125, 210);
            this.c_pcode_txt.Name = "c_pcode_txt";
            this.c_pcode_txt.Size = new System.Drawing.Size(200, 20);
            this.c_pcode_txt.TabIndex = 8;
            // 
            // c_county_txt
            // 
            this.c_county_txt.Location = new System.Drawing.Point(125, 180);
            this.c_county_txt.Name = "c_county_txt";
            this.c_county_txt.Size = new System.Drawing.Size(200, 20);
            this.c_county_txt.TabIndex = 9;
            // 
            // c_town_txt
            // 
            this.c_town_txt.Location = new System.Drawing.Point(125, 150);
            this.c_town_txt.Name = "c_town_txt";
            this.c_town_txt.Size = new System.Drawing.Size(200, 20);
            this.c_town_txt.TabIndex = 10;
            // 
            // c_add2_txt
            // 
            this.c_add2_txt.Location = new System.Drawing.Point(125, 120);
            this.c_add2_txt.Name = "c_add2_txt";
            this.c_add2_txt.Size = new System.Drawing.Size(200, 20);
            this.c_add2_txt.TabIndex = 11;
            // 
            // c_add1_txt
            // 
            this.c_add1_txt.Location = new System.Drawing.Point(125, 90);
            this.c_add1_txt.Name = "c_add1_txt";
            this.c_add1_txt.Size = new System.Drawing.Size(200, 20);
            this.c_add1_txt.TabIndex = 12;
            // 
            // c_sname_txt
            // 
            this.c_sname_txt.Location = new System.Drawing.Point(125, 60);
            this.c_sname_txt.Name = "c_sname_txt";
            this.c_sname_txt.Size = new System.Drawing.Size(200, 20);
            this.c_sname_txt.TabIndex = 13;
            // 
            // submit_btn
            // 
            this.submit_btn.Location = new System.Drawing.Point(125, 240);
            this.submit_btn.Name = "submit_btn";
            this.submit_btn.Size = new System.Drawing.Size(150, 25);
            this.submit_btn.TabIndex = 14;
            this.submit_btn.Text = "Insert / Update";
            this.submit_btn.UseVisualStyleBackColor = true;
            this.submit_btn.Click += new System.EventHandler(this.submit_btn_Click);
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 276);
            this.Controls.Add(this.submit_btn);
            this.Controls.Add(this.c_sname_txt);
            this.Controls.Add(this.c_add1_txt);
            this.Controls.Add(this.c_add2_txt);
            this.Controls.Add(this.c_town_txt);
            this.Controls.Add(this.c_county_txt);
            this.Controls.Add(this.c_pcode_txt);
            this.Controls.Add(this.c_fname_txt);
            this.Controls.Add(this.c_sname_lbl);
            this.Controls.Add(this.c_add1_lbl);
            this.Controls.Add(this.c_add2_lbl);
            this.Controls.Add(this.c_town_lbl);
            this.Controls.Add(this.c_county_lbl);
            this.Controls.Add(this.c_pcode_lbl);
            this.Controls.Add(this.c_fname_lbl);
            this.Name = "CustomerForm";
            this.Text = "Customer Form";
            this.ResumeLayout(false);
            this.PerformLayout();
            this.FormClosed +=
                new System.Windows.Forms.
                FormClosedEventHandler(this.CustomerForm_FormClosed);

        }

        #endregion

        private System.Windows.Forms.Label c_fname_lbl;
        private System.Windows.Forms.Label c_pcode_lbl;
        private System.Windows.Forms.Label c_county_lbl;
        private System.Windows.Forms.Label c_town_lbl;
        private System.Windows.Forms.Label c_add2_lbl;
        private System.Windows.Forms.Label c_add1_lbl;
        private System.Windows.Forms.Label c_sname_lbl;
        private System.Windows.Forms.TextBox c_fname_txt;
        private System.Windows.Forms.TextBox c_pcode_txt;
        private System.Windows.Forms.TextBox c_county_txt;
        private System.Windows.Forms.TextBox c_town_txt;
        private System.Windows.Forms.TextBox c_add2_txt;
        private System.Windows.Forms.TextBox c_add1_txt;
        private System.Windows.Forms.TextBox c_sname_txt;
        private System.Windows.Forms.Button submit_btn;
    }
}