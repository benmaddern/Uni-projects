﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using mySQLinterface;

namespace DatabaseUnitTests
{
    [TestClass]
    public class ValidationUnitTests
    {
        // instance to teh Mainform necessary for subform constructors
        MainForm mainform = new MainForm();

        [TestMethod]

        public void WishListFormNullDateTest()
        {
            //create an instance to test:
            WishlistForm wlForm = new WishlistForm(ref mainform, true);
            //Define a test input and output value:
            bool expectedResult = false;

            wlForm.SetDateAdded("0000-00-00");
            //run the method under test:
            bool actualResult = wlForm.ValidateFields();
            //verify the result:
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void WishListFormErroneousDateTest()
        {   //create an instance to test
            WishlistForm wlForm = new WishlistForm(ref mainform, true);
            //define a test input and out put value:
            bool expectedResult = false;

            wlForm.SetDateAdded("erroneous data");
            //run the method under test:
            bool actualResult = wlForm.ValidateFields();
            //verify the result:
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void WishListFormDateFormatTest()
        {
            //create an instance to test
            WishlistForm wlForm = new WishlistForm(ref mainform, true);
            //define a test input and out put value:
            bool expectedResult = false;

            wlForm.SetDateAdded("19-08-17");
            //run the method under test:
            bool actualResult = wlForm.ValidateFields();
            //verify the result:
            Assert.AreEqual(expectedResult, actualResult);
        }
    }
}
