//this variable has been created as we will likely use it more than once in this file, so it wil save space.
const staticCacheName = 'site-static-v8';

//dynamic cache variable
const dynamicCacheName = 'site-dynamic-v8';

//This array varable i am going to reference the cached assets
const assets = [
  '/',
  '/index.html',      //These first two are both the index page, but a user could make both requests to reach the index page so we cache both
  '/js/app.js',
  '/js/ui.js',        //Here we add the js files.
  '/js/materialize.min.js',
  '/css/styles.css',
  '/css/materialize.min.css',     //we cache all our css documents.
  '/img/icons/icon128.png',
  'https://fonts.googleapis.com/icon?family=Material+Icons',
  'https://fonts.gstatic.com/s/materialicons/v47/flUhRq6tzZclQEJ-Vdg-IuiaDsNcIhQ8tQ.woff2', //we have to cache these urls becuase if we cache our CSS, it is offline so cant reach the urls. 
  '/pages/fallback.html' //add the fallback page to the cache for offline-uncahced pages
];

// cache size limiter function
const limitCacheSize = (name, size) => {                          //add a variab;e with 2 arguments, name and size
  caches.open(name).then(cache => {                               //inside the function we use some asynchronous methods to get a cache name and use a then method
    cache.keys().then(keys => {                                   //this line checks the keys so checks all the elements of our cache. 
      if (keys.length > size) {                                     // here we say is the amount of keys is more than the size we want to do something
        cache.delete(keys[0]).then(limitCacheSize(name, size));   //we take position o in the array, the first item, and delete it, then we run the function again! 
      } //we check again becuase if we had 15 elements as a max, and we have 17, we need to delete two, this will loop until its no longer true. 
    });
  });
};

// Install the SW (Event)
self.addEventListener('install', evt => {
  evt.waitUntil( // wait until, so we dont class the SW as installed before we have finished caching.
    caches.open(staticCacheName).then((cache) => {   //it will check if it exists first anf if not it will create it and then open it. This is an sync task and will take time. 
      console.log('caching shell assets');          // console log for debugging 
      cache.addAll(assets);                         // add the assets we have added to our array.
      // .addALL is an array method we are using, we could also use the .add method for single elements. 
    })
  );
  //console.log('service worker installed');
});

//Activate event (listening)..
self.addEventListener('activate', evt => {
  evt.waitUntil(
    caches.keys().then(keys => {
      //console.log(keys);
      return Promise.all(keys
        .filter(key => key !== staticCacheName && key !== dynamicCacheName) //<<Tutor note: This includes the fix from the end of the worksheet.
        .map(key => caches.delete(key))
      );
    })
  );
  //console.log('service worker activated');
});

// fetch event - fired for every element requested
self.addEventListener('fetch', evt => {

  if (evt.request.url.indexOf('firestore.googleapis.com') === -1) {
    evt.respondWith(
      caches.match(evt.request).then(cacheRes => {    //open the new 'then' request
        return cacheRes || fetch(evt.request).then(fetchRes => {  //now we need to return something, so we are going to store this in a new cache called 
          return caches.open(dynamicCacheName).then(cache => {    //we put that respose into the cache now we declare at the top of this file
            cache.put(evt.request.url, fetchRes.clone());         //we use the put method here to add new items in the cache. We use the resource url (the key)

            limitCacheSize(dynamicCacheName, 15);

            return fetchRes;                                      // by using the clone method we can still return the url key and cache the required page. 
          })
        });
      }).catch(() => {
        if (evt.request.url.indexOf('.html') > -1) {  // if .html is not in the url, then it will automatically give us a -1.
          return caches.match('/pages/fallback.html'); //So if it is GREATER-THAN -1, we know it is a html and we send it back.
        }
      })
    );
    //console.log('fetch event', evt);
  }
});
