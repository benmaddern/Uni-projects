const quests = document.querySelector('.quests');

document.addEventListener('DOMContentLoaded', function () {
  // nav menu
  const menus = document.querySelectorAll('.side-menu');
  M.Sidenav.init(menus, { edge: 'right' });
  // add quest form
  const forms = document.querySelectorAll('.side-form');
  M.Sidenav.init(forms, { edge: 'left' });
});

//render quest data, when we run that function from the db.js file
const renderQuest = (data, id) => {
  const html = `
    <div class="card-panel quest white row" data-id="${id}">
    <img src="/img/icons/icon128.png" alt="quest thumb">
    <div class="quest-details">
      <div class="quest-title">${data.title}</div>
      <div class="quest-tasks">${data.tasks}</div>
    </div>
    <div class="quest-delete">
      <i class="material-icons" data-id="${id}">delete_outline</i>
    </div>
  </div>
    `;
  quests.innerHTML += html;
}

//remove quest card
const removeQuest = (id) => {
  const quest = document.querySelector(`.quest[data-id=${id}]`); //the square brackets here allow us to find the CSS class
  quest.remove();
}