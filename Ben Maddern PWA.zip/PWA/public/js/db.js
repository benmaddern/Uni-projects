//Offline data handling 
// enable offline data
db.enablePersistence()
  .catch(function(err) {
    if (err.code == 'failed-precondition') {
      // most likely cause is multible tabs open at once
      console.log('persistance failed');
    } else if (err.code == 'unimplemented') {
      // no browser support for the feature
      console.log('persistance not available');
    }
  });

//RT Listner
db.collection('quests').onSnapshot((snapshot) =>{
    //console.log(snapshot.docChanges());
    snapshot.docChanges().forEach(change => {
        //console.log(change, change.doc.data(), change.doc.id);
        if(change.type === 'added')
        {
            //add document data to web page
            renderQuest(change.doc.data(), change.doc.id);
        }
        if(change.type === 'removed')
        {
            //remove doc data from webpage
            removeQuest(change.doc.id); //pass this function (in ui.js) the document id. 
        }
    });
})

// add new quest
const form = document.querySelector('form'); //this is a reference to the form we already have
form.addEventListener('submit', evt => {  //listen for the submit button and fire a callback
  evt.preventDefault();   //stop the defult action which it refreshing the page
  
  const quest = {                     //a new object variable,
    title: form.title.value,   //these values relate to our form on the index.html page, where we have our <form> html. 
    tasks: form.tasks.value    //we use the id="" elements here on both the title and tasks.
  };

  db.collection('quests').add(quest)  //add to our quests collection in firebase
    .catch(err => console.log(err)); //catch if there are any errors and 

  form.title.value = ''; //return a value as a user input
  form.tasks.value = '';
});

//delete quests
const questContainer = document.querySelector('.quests');
questContainer.addEventListener('click', evt => {  //make an event listner to listen out for click events
  if(evt.target.tagName === 'I'){ //make sure the tag name is equal to I (i found it was capital with the console log below)
    const id = evt.target.getAttribute('data-id'); //this data-id is what we added to the html block in ui.js
    //console.log(id);  // I used this to check where i was clicking in the console log and ensure what I was trying to do was actually possile.
    db.collection('quests').doc(id).delete(); //we pass the id of the document to firestore to do all the work for us again! 
  }
})


